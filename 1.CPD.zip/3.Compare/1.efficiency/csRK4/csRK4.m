function [CPUtime,err,energy_err]=csRK4(tau)

tic;

options=optimset;
options = optimset(options,'TolX',1e-14);
options = optimset(options,'TolFun',1e-14);
options = optimset(options,'MaxFunEvals',Inf);
options=optimset(options,'Display','off');
options=optimset(options,'Algorithm','levenberg-marquardt');

m=3;  epsilon=0.1;  Im=eye(m);  om=zeros(m,m);  om1=zeros(m,1);
B=[0 1 0;-1 0 0;0 0 0];  S=[(1/epsilon)*B -Im;Im om];  Q=[Im om;om om];  L=S*Q;
Vn=[0.09;0.05;0.2];  Xn=[0;1;0.1];  Zn=[Vn;Xn]; 
func_f=@(X)[-4*X(1)-cos(X(1)+X(2)+X(3));-4*X(2)-cos(X(1)+X(2)+X(3));-4*X(3)-cos(X(1)+X(2)+X(3))];
[coe1,coe2,coe3,coe4,coe5,coe6,GW]=generate_coefficient;

T=1;  tn=0;  Energy=compute_energy(Zn,m); 
while (tn<(T-0.5*tau))
    ZZ=fsolve(@(ZZ)equation(ZZ,Zn,tau,L,om1,m,coe1,coe2,coe3,coe4,coe5,coe6,GW,func_f),[Zn;Zn],options);  
    Zn=ZZ(2*m+1:end,1);  tn=tn+tau;
    Energy=[Energy compute_energy(Zn,m)];
end
toc;  CPUtime=toc;
load reference.mat;  err=max(abs(Zn-Zn_Gauss4_10000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));