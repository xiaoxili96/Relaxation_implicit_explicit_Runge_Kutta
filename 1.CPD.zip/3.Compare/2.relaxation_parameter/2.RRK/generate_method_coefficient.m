function [A,b]=generate_method_coefficient(method)

if (method == 'RK2')
    
    %%%% Runge
    A=[0 0;0.5 0];  b=[0 1];
    
elseif (method == 'RK3')
    
    %%%% Heun
    A=[0 0 0;1/3 0 0;0 2/3 0];  b=[1/4 0 3/4];
    
elseif (method == 'RK4')
    
    %%%% Gill
    A=[0 0 0 0;1/2 0 0 0;(sqrt(2)-1)/2 (2-sqrt(2))/2 0 0;0 -sqrt(2)/2 (2+sqrt(2))/2 0];
    b=[1/6 (2-sqrt(2))/6 (2+sqrt(2))/6 1/6];
    
else 
    
    fprintf('Please add the coefficients of the method of desired accuracy!')
    
end