function [tmesh,GAMMA]=solver(tau,method)

m=3;  epsilon=0.1;  Im=eye(m);  om=zeros(m,m);
B=[0 1 0;-1 0 0;0 0 0];  S=[(1/epsilon)*B -Im;Im om];  Q=[Im om;om om];  
L=S*Q;  Vn=[0.09;0.05;0.2];  Xn=[0;1;0.1];  Zn=[Vn;Xn];

[A,b]=generate_method_coefficient(method);  s=size(A,1);

T=1;  tn=0;  tmesh=tn;  GAMMA=[];
while (tn<(T-tau))
    Zmid(:,1)=Zn;  
    Fmid(:,1)=compute_nonlinear(Zmid(:,1),m);  %%%%
    for k=2:s
        Zmid(:,k)=Zn+tau*(L*Zmid(:,1:(k-1))+Fmid(:,1:(k-1)))*(A(k,1:(k-1)))';
        Fmid(:,k)=compute_nonlinear(Zmid(:,k),m);  %%%%
    end
    Update=tau*(L*Zmid+Fmid)*b';  Update_norm=sum(abs(Update).^2);
    energy_old=compute_energy(Zn,m);  %%%%    
    if ( Update_norm==0 )
        gamma=1;
    else
        gamma=fzero(@(gamma)func_of_gamma(Zn,Update,m,energy_old,gamma),1);  %%%%
    end
    fprintf('tn=%d,distance=%d\n',tn,abs(gamma-1));
    GAMMA=[GAMMA gamma];
    Zn_save=Zn;  tn_save=tn;
    Zn=Zn+gamma*Update;  tn=tn+gamma*tau
    tmesh=[tmesh tn];
end

if ( (T-tn)<=0 )
    tmesh=tmesh(1:end-1);  GAMMA=GAMMA(1:end-1);
    Zn=Zn_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
Zmid(:,1)=Zn;  
Fmid(:,1)=compute_nonlinear(Zmid(:,1),m);  %%%%
for k=2:s
    Zmid(:,k)=Zn+tau*(L*Zmid(:,1:(k-1))+Fmid(:,1:(k-1)))*(A(k,1:(k-1)))';
    Fmid(:,k)=compute_nonlinear(Zmid(:,k),m);  %%%%
end
Zn=Zn+tau*(L*Zmid+Fmid)*b';  tn=tn+tau
tmesh=[tmesh tn];