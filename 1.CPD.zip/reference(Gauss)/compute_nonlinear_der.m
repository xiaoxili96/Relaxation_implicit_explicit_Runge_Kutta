function F_der=compute_nonlinear_der(Zmid,d,s,m)

Zmid_reshape=reshape(Zmid,d,s);  
X1=Zmid_reshape(m+1,:);  X2=Zmid_reshape(m+2,:);  X3=Zmid_reshape(m+3,:);
F_der=zeros(d*s,d*s);
coe=sin(X1+X2+X3);  I=(-4)*eye(m,m);  E=ones(m,m);
A1=I+coe(1)*E;
A2=I+coe(2)*E;
% A3=I+coe(3)*E;
% A4=I+coe(4)*E;
F_der(1    :3,    m+1    :m+3)    =A1;
F_der(1+d  :3+d,  m+1+d  :m+3+d)  =A2;
% F_der(1+2*d:3+2*d,m+1+2*d:m+3+2*d)=A3;
% F_der(1+3*d:3+3*d,m+1+3*d:m+3+3*d)=A4;

