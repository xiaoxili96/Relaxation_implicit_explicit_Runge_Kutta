function F=compute_nonlinear(Zmid,d,s,m)

Zmid_reshape=reshape(Zmid,d,s);  
X1=Zmid_reshape(m+1,:);  X2=Zmid_reshape(m+2,:);  X3=Zmid_reshape(m+3,:);  val=cos(X1+X2+X3);
F=[4*X1+val;4*X2+val;4*X3+val;zeros(m,s)];  F=-F;
F=F(:);
