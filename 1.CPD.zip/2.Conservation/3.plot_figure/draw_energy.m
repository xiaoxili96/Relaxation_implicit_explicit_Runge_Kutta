%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);   
load('IERK2.mat');
tmesh_2=tmesh;  Energy_2=Energy;  CPUtime_2=CPUtime;  
load('IERK3.mat');
tmesh_3=tmesh;  Energy_3=Energy;  CPUtime_3=CPUtime;  
load('IERK4.mat');
tmesh_4=tmesh;  Energy_4=Energy;  CPUtime_4=CPUtime;  
load('RIERK2.mat');
tmesh_r2=tmesh;  Energy_r2=Energy;  CPUtime_r2=CPUtime;  
load('RIERK3.mat');
tmesh_r3=tmesh;  Energy_r3=Energy;  CPUtime_r3=CPUtime;  
load('RIERK4.mat');
tmesh_r4=tmesh;  Energy_r4=Energy;  CPUtime_r4=CPUtime; 


axes(p(1));    % ��ȡ��ǰfigure����Ϣ
semilogy(tmesh_2,abs(Energy_2-Energy_2(1))/abs(Energy_2(1)),':r','LineWidth',2);  hold on;
semilogy(tmesh_r2(1:end-1),abs(Energy_r2(1:end-1)-Energy_r2(1))/abs(Energy_r2(1)),'r','LineWidth',2);
semilogy(tmesh_3,abs(Energy_3-Energy_3(1))/abs(Energy_3(1)),':g','LineWidth',2);
semilogy(tmesh_r3(1:end-1),abs(Energy_r3(1:end-1)-Energy_r3(1))/abs(Energy_r3(1)),'g','LineWidth',2);
semilogy(tmesh_4,abs(Energy_4-Energy_4(1))/abs(Energy_4(1)),':b','LineWidth',2);
semilogy(tmesh_r4(1:end-1),abs(Energy_r4(1:end-1)-Energy_r4(1))/abs(Energy_r4(1)),'b','LineWidth',2);
box on;  set(gca,'linewidth',2,'FontSize',30);
set(gca,'XLim',[0 200]);  set(gca,'YLim',[10^(-16) 100]);
xlabel('$t$','interpreter','latex','FontSize',30);
ylabel('$D^n$ or $D^n_\gamma$','interpreter','latex','FontSize',30);
legend('IERK2: $\tau=1/200$, $t_c=8.99s$', ...
       'RIERK2: $\tau=1/2$, $t_c=0.48s$', ...
       'IERK3: $\tau=1/200$, $t_c=9.54s$', ...
       'RIERK3: $\tau=1/2$, $t_c=0.50s$', ...
       'IERK4: $\tau=1/200$, $t_c=11.03s$', ...
       'RIERK4: $\tau=1/2$, $t_c=0.52s$');  
set(legend,'interpreter','latex','location','northwest','FontSize',16); 