function result=func_of_gamma(Zn,Update,m,energy_old,gamma)

result=compute_energy(Zn+gamma*Update,m)-energy_old;