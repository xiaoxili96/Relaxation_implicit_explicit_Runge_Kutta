function [CPUtime,err,energy_err]=AVF(tau)

tic;

N=20;  left=-7;  right=7;  bottom=-7; top=7;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=bottom+0.5*h:h:top-0.5*h;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=diag(ones(N-1,1),1)+diag(ones(N-1,1),-1);  K=kron(KK,speye(N))+kron(speye(N),KK);  K=K+(-1)*diag(sum(K,2));  K=(1/h/h)*K;  d=size(K,1);  
L=[sparse(d,d) K;speye(d) sparse(d,d)];  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  Zn=[Vn;Un];
func_f_der=@(x)(-1)*(cos(x));  func_F=@(x)cos(x);  func_f=@(x)(-1)*(sin(x));
[GP,GW]=generate_GP_GW;

T=1;  tn=0;  Energy=[];  dd=size(L,1);  Idd=eye(dd);
while (tn<(T-0.5*tau)) 
    iter_err=1;  iter_count=0;  Un=Zn(d+1:2*d);  Zn1=Zn;  
    while ((iter_err >= 10^(-14)) && (iter_count < 100))
        Znew=Zn1-Zn;  Unew=Znew(d+1:2*d);
        U1=Un+GP(1)*Unew;  F1=func_f(U1);
        U2=Un+GP(2)*Unew;  F2=func_f(U2);
        U3=Un+GP(3)*Unew;  F3=func_f(U3);
        U4=Un+GP(4)*Unew;  F4=func_f(U4);
        U5=Un+GP(5)*Unew;  F5=func_f(U5);
        F=GW(1)*F1+GW(2)*F2+GW(3)*F3+GW(4)*F4+GW(5)*F5;
        vector=Zn1-Zn-0.5*tau*L*(Zn1+Zn)-tau*[F;zeros(d,1)];
        F_der=GW(1)*GP(1)*diag(func_f_der(U1)) ...
             +GW(2)*GP(2)*diag(func_f_der(U2)) ...
             +GW(3)*GP(3)*diag(func_f_der(U3)) ...
             +GW(4)*GP(4)*diag(func_f_der(U4)) ...
             +GW(5)*GP(5)*diag(func_f_der(U5));
        Matrix=Idd-0.5*tau*L-tau*([[zeros(d,d) F_der];zeros(d,2*d)]);
        Zn1_save=Zn1;  Zn1=Zn1-Matrix\vector;
        iter_err=max(abs(Zn1_save-Zn1));  iter_count=iter_count+1;
    end
    Zn=Zn1;  tn=tn+tau;
    Energy=[Energy compute_energy(Zn,d,h,func_F,K)];
end
toc;  CPUtime=toc;
load('reference.mat');  err=max(abs(Zn-Xn_Gauss4_1000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));