function result=func_of_gamma(Xn,Update,d,K,h,func_F,energy_old,gamma)

result=compute_energy(Xn+gamma*Update,d,K,h,func_F)-energy_old;