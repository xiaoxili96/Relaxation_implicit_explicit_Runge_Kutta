function result=compute_energy(X,d,K,h,func_F)

V=X(1:d,1);  U=X(d+1:2*d,1);
result=0.5*h*h*(V'*V)-0.5*h*h*(U'*K*U)-h*h*sum(func_F(U));

