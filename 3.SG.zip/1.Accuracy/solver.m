function [Zn,gamma_average]=solver(tau,method)

N=20;  left=-7;  right=7;  bottom=-7; top=7;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=bottom+0.5*h:h:top-0.5*h;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=diag(ones(N-1,1),1)+diag(ones(N-1,1),-1);  K=kron(KK,speye(N))+kron(speye(N),KK);  K=K+(-1)*diag(sum(K,2));  K=(1/h/h)*K;  d=size(K,1);  
L=[sparse(d,d) K;speye(d) sparse(d,d)];  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  Zn=[Vn;Un];
func_F=@(x)cos(x);  func_f=@(x)(-1)*(sin(x));

[Ai,bi,Ae,be]=generate_method_coefficient(method);  s=size(Ai,1);  dd=size(L,1);  Idd=speye(dd);
A_coe=zeros(s*dd,dd);
for k=1:s
    A_coe(1+(k-1)*dd:k*dd,:)=(Idd-tau*Ai(k,k)*L)^(-1);
end

T=1;  tn=0;  GAMMA=[];
while (tn<(T-tau))
    Zmid(:,1)=A_coe(1:dd,:)*Zn;  
    Fmid(:,1)=compute_nonlinear(Zmid(:,1),func_f,d);  %%%%
    for k=2:s
        Zmid(:,k)=A_coe(1+(k-1)*dd:k*dd,:)*(Zn+tau*L*Zmid(:,1:(k-1))*(Ai(k,1:(k-1)))'+tau*Fmid(:,1:(k-1))*(Ae(k,1:(k-1)))');
        Fmid(:,k)=compute_nonlinear(Zmid(:,k),func_f,d);  %%%%
    end
    Update=tau*L*Zmid*bi'+tau*Fmid*be';  Update_norm=sum(abs(Update).^2);
    energy_old=compute_energy(Zn,d,h,func_F,K);  %%%%    
    if ( Update_norm==0 )
        gamma=1;
    else
        gamma=fzero(@(gamma)func_of_gamma(Zn,Update,d,K,h,func_F,energy_old,gamma),1);  %%%%
    end
    GAMMA=[GAMMA gamma];
    Zn_save=Zn;  tn_save=tn;
    Zn=Zn+gamma*Update;  tn=tn+gamma*tau
end

if ( (T-tn)<=0 )
    GAMMA=GAMMA(1:end-1);
    Zn=Zn_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
Zmid(:,1)=(Idd-tau*Ai(1,1)*L)\Zn;  
Fmid(:,1)=compute_nonlinear(Zmid(:,1),func_f,d);  %%%%
for k=2:s
    Zmid(:,k)=(Idd-tau*Ai(k,k)*L)\(Zn+tau*L*Zmid(:,1:(k-1))*(Ai(k,1:(k-1)))'+tau*Fmid(:,1:(k-1))*(Ae(k,1:(k-1)))');
    Fmid(:,k)=compute_nonlinear(Zmid(:,k),func_f,d);  %%%%
end
Zn=Zn+tau*L*Zmid*bi'+tau*Fmid*be';  tn=tn+tau

gamma_average=(sum(abs(GAMMA-1)))/(size(GAMMA,2));