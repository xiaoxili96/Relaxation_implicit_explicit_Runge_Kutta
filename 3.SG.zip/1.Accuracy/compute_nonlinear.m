function F=compute_nonlinear(Zn,func_f,d)

F=[func_f(Zn(d+1:2*d)); zeros(d,1)];


