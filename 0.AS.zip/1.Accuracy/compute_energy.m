function result=compute_energy(Zn,rho)

x1=Zn(1);  x2=Zn(2);
result=0.5*rho*(x1^2+x2^2)-0.5*(x1*x2^2-(1/3)*x1^3);