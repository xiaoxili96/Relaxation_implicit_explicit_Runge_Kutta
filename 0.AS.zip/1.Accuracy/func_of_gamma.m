function result=func_of_gamma(Zn,Update,rho,energy_old,gamma)

result=compute_energy(Zn+gamma*Update,rho)-energy_old;