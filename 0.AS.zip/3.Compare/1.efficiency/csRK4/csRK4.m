function [CPUtime,err,energy_err]=csRK4(tau)

tic;

options=optimset;
options = optimset(options,'TolX',1e-14);
options = optimset(options,'TolFun',1e-14);
options = optimset(options,'MaxFunEvals',Inf);
options=optimset(options,'Display','off');
options=optimset(options,'Algorithm','levenberg-marquardt');

rho=10;  L=rho*[0 -1;1 0];  Zn=[-1;2];  d=size(L,2);
func_f=@(X)[X(1)*X(2); 0.5*(X(1)^2-X(2)^2)];
[coe1,coe2,coe3,coe4,coe5,coe6,GW]=generate_coefficient;

T=1;  tn=0;  Energy=compute_energy(Zn,rho); 
while (tn<(T-0.5*tau))
    ZZ=fsolve(@(ZZ)equation(ZZ,Zn,tau,L,d,coe1,coe2,coe3,coe4,coe5,coe6,GW,func_f),[Zn;Zn],options);  
    Zn=ZZ(d+1:end,1);  tn=tn+tau;
    Energy=[Energy compute_energy(Zn,rho)];
end
toc;  CPUtime=toc;
load reference.mat;  err=max(abs(Zn-Zn_c_100000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));