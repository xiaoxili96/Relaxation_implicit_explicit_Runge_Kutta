function result=equation(ZZ,Zn,tau,L,d,coe1,coe2,coe3,coe4,coe5,coe6,GW,func_f)

Zm=ZZ(1:d,1);  Zn1=ZZ(d+1:end,1); 
Yn=L*Zn;  Ym=L*Zm;  Yn1=L*Zn1;
L1=coe5(1)*Yn+coe5(2)*Ym+coe5(3)*Yn1;  L2=coe6(1)*Yn+coe6(2)*Ym+coe6(3)*Yn1;
Z1=coe1(1)*Zn+coe2(1)*Zm+coe3(1)*Zn1;  Z2=coe1(2)*Zn+coe2(2)*Zm+coe3(2)*Zn1;
Z3=coe1(3)*Zn+coe2(3)*Zm+coe3(3)*Zn1;  Z4=coe1(4)*Zn+coe2(4)*Zm+coe3(4)*Zn1;
Z5=coe1(5)*Zn+coe2(5)*Zm+coe3(5)*Zn1;
FF1=func_f(Z1);  FF2=func_f(Z2);  FF3=func_f(Z3);  FF4=func_f(Z4);  FF5=func_f(Z5);
F1=coe4(1)*FF1+coe4(2)*FF2+coe4(3)*FF3+coe4(4)*FF4+coe4(5)*FF5;
F2=GW(1)*FF1+GW(2)*FF2+GW(3)*FF3+GW(4)*FF4+GW(5)*FF5;
result=ZZ-[Zn;Zn]-tau*[L1;L2]-tau*[F1;F2];