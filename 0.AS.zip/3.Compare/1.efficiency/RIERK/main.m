method='IERK4';
% stepsize=[1/16 1/32 1/64 1/128 1/256];  % IERK2
stepsize=[1/64 1/128 1/256 1/512 1/1024];  % IERK2

ERR=[];  TIME=[];  ENERGY_ERR=[]; 
for k=1:size(stepsize,2)
    tau=stepsize(1,k);
    [CPUtime,err,energy_err]=solver(tau,method); 
    TIME=[TIME CPUtime];
    ERR=[ERR err]; 
    ENERGY_ERR=[ENERGY_ERR energy_err];
end

Err_order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))