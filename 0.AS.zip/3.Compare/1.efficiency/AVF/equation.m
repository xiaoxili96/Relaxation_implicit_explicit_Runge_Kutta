function result=equation(Zn1,Zn,tau,L,GP,GW,func_f)

new=Zn1-Zn;
Z1=Zn+GP(1)*new;  Z2=Zn+GP(2)*new;  Z3=Zn+GP(3)*new;  Z4=Zn+GP(4)*new;  Z5=Zn+GP(5)*new;
F=GW(1)*func_f(Z1)+GW(2)*func_f(Z2)+GW(3)*func_f(Z3)+GW(4)*func_f(Z4)+GW(5)*func_f(Z5);
result=Zn1-Zn-0.5*tau*L*(Zn1+Zn)-tau*F;