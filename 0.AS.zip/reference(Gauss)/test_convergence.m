stepsize=[1/2 1/4 1/8 1/16 1/32 1/64 1/128 1/256];

Z_c=Solver(stepsize(end));

Err=[];
for k=1:size(stepsize,2)-1
    Zn=Solver(stepsize(k));
    Err=[Err max(abs(Z_c-Zn))];
end

Err
order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-2)./stepsize(2:end-1))
