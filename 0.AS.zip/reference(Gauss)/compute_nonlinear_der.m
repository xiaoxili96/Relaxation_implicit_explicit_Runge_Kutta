function F_der=compute_nonlinear_der(Zmid,d,s)

x11=Zmid(1);
x12=Zmid(2);
x21=Zmid(3);
x22=Zmid(4);
x31=Zmid(5);
x32=Zmid(6);
x41=Zmid(7);
x42=Zmid(8);
F_der=zeros(d*s,d*s);
F_der(1    :d,  1    :d)  =[x12 x11;x11 -x12];
F_der(1+d  :2*d,1+d  :2*d)=[x22 x21;x21 -x22];
F_der(1+2*d:3*d,1+2*d:3*d)=[x32 x31;x31 -x32];
F_der(1+3*d:4*d,1+3*d:4*d)=[x42 x41;x41 -x42];

