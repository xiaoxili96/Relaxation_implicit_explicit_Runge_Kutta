function result=extrapolate_coe(t1,t2,c,tau1,tau2)
s=size(c,1);
midpoint1=t1+c*tau1;  midpoint2=t2+c*tau2;  result=zeros(s,s);
for k=1:s
    coe=ones(s,1);
    for kk=1:s
        if kk == k
            continue;
        else
            coe=coe.*(midpoint2-midpoint1(kk))/(midpoint1(k)-midpoint1(kk));
        end
    end
    result(:,k)=coe;
end

