function [CPUtime,err,energy_err]=AVF(tau)

tic;

N=100;  left=0;  right=1.28;  LL=right-left;  h=LL/N;  xmesh=left:h:right-h;  
freq=(2*pi/LL)*[0:N/2-1 -N/2:-1];  K=diag(freq.^2);  W_hat=fft(eye(N));  W=ifft(eye(N));     
L=[zeros(N,N) -K; eye(N) zeros(N,N)];  Zn=[zeros(1,N) (1/N)*(fft(20*(1+cos((2*pi/LL)*xmesh'))))']';
func_f_der=@(x)(-1)*(3*x.^2+1);  func_f=@(x)(-1)*(x.^3+x);  func_F=@(x)(-1)*(0.25*x.^4+0.5*x.^2);
[GP,GW]=generate_GP_GW;

T=1;  tn=0;  Energy=[];  dd=size(L,1);  Idd=eye(dd);
while (tn<(T-0.5*tau)) 
    iter_err=1;  iter_count=0;  Un=Zn(N+1:2*N);  Zn1=Zn;  
    while ((iter_err >= 10^(-14)) && (iter_count < 100))
        Znew=Zn1-Zn;  Unew=Znew(N+1:2*N);
        U1=Un+GP(1)*Unew;  U1p=real(N*ifft(U1));  F1=(1/N)*fft(func_f(U1p));
        U2=Un+GP(2)*Unew;  U2p=real(N*ifft(U2));  F2=(1/N)*fft(func_f(U2p));
        U3=Un+GP(3)*Unew;  U3p=real(N*ifft(U3));  F3=(1/N)*fft(func_f(U3p));
        U4=Un+GP(4)*Unew;  U4p=real(N*ifft(U4));  F4=(1/N)*fft(func_f(U4p));
        U5=Un+GP(5)*Unew;  U5p=real(N*ifft(U5));  F5=(1/N)*fft(func_f(U5p));
        F=GW(1)*F1+GW(2)*F2+GW(3)*F3+GW(4)*F4+GW(5)*F5;
        vector=Zn1-Zn-0.5*tau*L*(Zn1+Zn)-tau*[F;zeros(N,1)];
        F_der=W_hat*( GW(1)*GP(1)*diag(func_f_der(U1p)) ...
                     +GW(2)*GP(2)*diag(func_f_der(U2p)) ...
                     +GW(3)*GP(3)*diag(func_f_der(U3p)) ...
                     +GW(4)*GP(4)*diag(func_f_der(U4p)) ...
                     +GW(5)*GP(5)*diag(func_f_der(U5p)) )*W;
        Matrix=Idd-0.5*tau*L-tau*([[zeros(N,N) F_der];zeros(N,2*N)]);
        Zn1_save=Zn1;  Zn1=Zn1-Matrix\vector;
        iter_err=max(abs(Zn1_save-Zn1));  iter_count=iter_count+1;
    end
    Zn=Zn1;  tn=tn+tau;
    Energy=[Energy compute_energy(Zn,N,LL,K,h,func_F)];
end
toc;  CPUtime=toc;
load('reference.mat');  err=max(abs(Zn-Xn_t_Gauss4_100000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));