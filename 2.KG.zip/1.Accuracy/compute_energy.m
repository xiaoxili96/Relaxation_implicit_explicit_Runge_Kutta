function result=compute_energy(Zn,N,LL,K,h,func_F)

Vn=Zn(1:N,1);  Un=Zn(N+1:2*N,1);
result=0.5*LL*abs(Vn'*Vn)+0.5*LL*abs(Un'*K*Un)-h*sum(func_F(real(N*ifft(Un))));