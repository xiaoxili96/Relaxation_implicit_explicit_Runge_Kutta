function result=func_of_gamma(Zn,Update,N,LL,K,h,func_F,energy_old,gamma)

result=compute_energy(Zn+gamma*Update,N,LL,K,h,func_F)-energy_old;